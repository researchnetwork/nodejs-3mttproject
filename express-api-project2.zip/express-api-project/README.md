# Simple REST API with Express.js

This project is a simple RESTful API built with Node.js and Express.js as part of a mini-project assessment. It demonstrates the fundamental principles of creating a REST API, including routing, data management in memory, and error handling.

## Objective

The goal of this assessment is to evaluate the ability to create a simple REST API using Express.js. It demonstrates an understanding of Node.js, Express.js, and RESTful API principles.

## Features

-   **CRUD Operations:** Full Create, Read, Update, and Delete functionality for items.
-   **In-Memory Storage:** Uses a simple JavaScript array as an in-memory database.
-   **Validation:** Validates incoming data for required fields.
-   **Error Handling:** Provides meaningful error messages with correct HTTP status codes.

## Setup and Installation

To run this project locally, you will need to have [Node.js](https://nodejs.org/) and `npm` installed.

1.  **Clone the repository or download the source code.**

2.  **Navigate to the project directory:**
    ```bash
    cd express-api-project
    ```

3.  **Install the necessary dependencies:**
    ```bash
    npm install
    ```

4.  **Start the server:**
    ```bash
    node index.js
    ```

The API will be running on `http://localhost:3000`.

---

## API Documentation (Endpoints)

This section provides details on the available API endpoints, including example requests and responses as you might see them in a tool like Postman.

### **1. Get Hello World**

-   **Description:** A simple root endpoint to confirm the server is running.
-   **Endpoint:** `GET /`
-   **Request:**
    ```
    GET http://localhost:3000/
    ```
-   **Success Response (200 OK):**
    ```
    Hello, World!
    ```

### **2. Get All Items**

-   **Description:** Retrieves a list of all items.
-   **Endpoint:** `GET /items`
-   **Request:**
    ```
    GET http://localhost:3000/items
    ```
-   **Success Response (200 OK):**
    ```json
    [
        {
            "id": 1,
            "name": "Laptop",
            "description": "A powerful computing device for work and play."
        },
        {
            "id": 2,
            "name": "Smartphone",
            "description": "A handheld device that combines mobile telephone and computing functions."
        }
    ]
    ```

### **3. Get a Single Item**

-   **Description:** Retrieves a single item by its unique ID.
-   **Endpoint:** `GET /items/:id`
-   **Request:**
    ```
    GET http://localhost:3000/items/1
    ```
-   **Success Response (200 OK):**
    ```json
    {
        "id": 1,
        "name": "Laptop",
        "description": "A powerful computing device for work and play."
    }
    ```
-   **Error Response (404 Not Found):**
    ```json
    {
        "message": "Item not found"
    }
    ```

### **4. Create a New Item**

-   **Description:** Adds a new item to the collection.
-   **Endpoint:** `POST /items`
-   **Request Body (JSON):**
    ```json
    {
        "name": "Wireless Keyboard",
        "description": "A mechanical keyboard with Bluetooth connectivity."
    }
    ```
-   **Success Response (201 Created):**
    ```json
    {
        "id": 3,
        "name": "Wireless Keyboard",
        "description": "A mechanical keyboard with Bluetooth connectivity."
    }
    ```
-   **Error Response (400 Bad Request):**
    ```json
    {
        "message": "Bad Request: Name and description are required."
    }
    ```

### **5. Update an Item**

-   **Description:** Updates an existing item by its ID.
-   **Endpoint:** `PUT /items/:id`
-   **Request Body (JSON):**
    ```json
    {
        "name": "Gaming Laptop",
        "description": "A high-performance laptop with a dedicated GPU."
    }
    ```
-   **Request Example:**
    ```
    PUT http://localhost:3000/items/1
    ```
-   **Success Response (200 OK):**
    ```json
    {
        "id": 1,
        "name": "Gaming Laptop",
        "description": "A high-performance laptop with a dedicated GPU."
    }
    ```
-   **Error Responses:**
    -   **404 Not Found:** If the item ID does not exist.
        ```json
        {
            "message": "Item not found"
        }
        ```
    -   **400 Bad Request:** If the `name` or `description` is missing from the body.
        ```json
        {
            "message": "Bad Request: Name and description are required."
        }
        ```

### **6. Delete an Item**

-   **Description:** Deletes an item by its ID.
-   **Endpoint:** `DELETE /items/:id`
-   **Request:**
    ```
    DELETE http://localhost:3000/items/2
    ```
-   **Success Response (204 No Content):**
    -   The server returns an empty response with a status code of 204.
-   **Error Response (404 Not Found):**
    ```json
    {
        "message": "Item not found"
    }
    ```