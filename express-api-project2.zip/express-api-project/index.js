// index.js

const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

// --- Task 1: Setting Up the API ---
// Set up proper middleware for parsing request bodies
app.use(express.json()); // This middleware parses incoming requests with JSON payloads.

// --- Task 3: Data Management ---
// Create a simple in-memory data store (array) to manage items.
// Each item has id, name, and description.
let items = [
    { id: 1, name: 'Laptop', description: 'A powerful computing device for work and play.' },
    { id: 2, name: 'Smartphone', description: 'A handheld device that combines mobile telephone and computing functions.' }
];
let currentId = items.length;

// --- Task 1: Setting Up the API ---
// Define a route for the root URL ('/') that returns a "Hello, World!" message
app.get('/', (req, res) => {
    res.send('Hello, World!');
});

// --- Task 2: Creating Routes (CRUD Operations) ---

// GET /items - Retrieve all items
app.get('/items', (req, res) => {
    res.status(200).json(items);
});

// GET /items/:id - Retrieve a single item by ID
app.get('/items/:id', (req, res) => {
    const itemId = parseInt(req.params.id, 10);
    const item = items.find(i => i.id === itemId);

    if (item) {
        res.status(200).json(item);
    } else {
        // Task 4: Error Handling - Implement appropriate error responses (404)
        res.status(404).json({ message: 'Item not found' });
    }
});

// POST /items - Create a new item
app.post('/items', (req, res) => {
    // Task 3 & 4: Implement proper validation for incoming data
    const { name, description } = req.body;

    if (!name || !description) {
        // Task 4: Error Handling - Validate request body data (400)
        return res.status(400).json({ message: 'Bad Request: Name and description are required.' });
    }

    const newItem = {
        id: ++currentId,
        name: name,
        description: description
    };

    items.push(newItem);
    res.status(201).json(newItem);
});

// PUT /items/:id - Update an item by ID
app.put('/items/:id', (req, res) => {
    const itemId = parseInt(req.params.id, 10);
    const itemIndex = items.findIndex(i => i.id === itemId);

    if (itemIndex !== -1) {
        // Task 3 & 4: Implement proper validation for incoming data
        const { name, description } = req.body;
        if (!name || !description) {
            // Task 4: Error Handling - Validate request body data (400)
            return res.status(400).json({ message: 'Bad Request: Name and description are required.' });
        }

        const updatedItem = {
            id: itemId,
            name: name,
            description: description
        };

        items[itemIndex] = updatedItem;
        res.status(200).json(updatedItem);
    } else {
        // Task 4: Error Handling - Implement appropriate error responses (404)
        res.status(404).json({ message: 'Item not found' });
    }
});

// DELETE /items/:id - Delete an item by ID
app.delete('/items/:id', (req, res) => {
    const itemId = parseInt(req.params.id, 10);
    const itemIndex = items.findIndex(i => i.id === itemId);

    if (itemIndex !== -1) {
        items.splice(itemIndex, 1);
        res.status(204).send(); // 204 No Content is standard for successful deletion
    } else {
        // Task 4: Error Handling - Implement appropriate error responses (404)
        res.status(404).json({ message: 'Item not found' });
    }
});

// --- Task 1 & 4: Error Handling ---
// Implement error handling for invalid routes (404 Not Found)
app.use((req, res, next) => {
    res.status(404).json({ message: 'Route not found' });
});

// Implement a generic error handler for other errors (500 Internal Server Error)
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ message: 'Internal Server Error' });
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});